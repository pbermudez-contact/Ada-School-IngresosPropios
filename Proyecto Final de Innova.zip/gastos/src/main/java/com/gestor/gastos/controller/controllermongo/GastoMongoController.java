package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.GastoMongo;
import com.gestor.gastos.service.servicemongo.GastoMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mongo/gastos")
public class GastoMongoController {

    @Autowired
    private GastoMongoService gastoMongoService;

    @GetMapping
    public List<GastoMongo> getAllGastos() {
        return gastoMongoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GastoMongo> getGastoById(@PathVariable String id) {
        return gastoMongoService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public GastoMongo createGasto(@RequestBody GastoMongo gasto) {
        return gastoMongoService.save(gasto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateGasto(@PathVariable String id, @RequestBody GastoMongo gasto) {
        return gastoMongoService.update(id, gasto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGasto(@PathVariable String id) {
        gastoMongoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}