package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.IngresoMongo;
import com.gestor.gastos.service.servicemongo.IngresoMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mongo/ingresos")
public class IngresoMongoController {

    @Autowired
    private IngresoMongoService ingresoMongoService;

    @GetMapping
    public List<IngresoMongo> getAllIngresos() {
        return ingresoMongoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<IngresoMongo> getIngresoById(@PathVariable String id) {
        return ingresoMongoService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public IngresoMongo createIngreso(@RequestBody IngresoMongo ingreso) {
        return ingresoMongoService.save(ingreso);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateIngreso(@PathVariable String id, @RequestBody IngresoMongo ingreso) {
        return ingresoMongoService.update(id, ingreso)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteIngreso(@PathVariable String id) {
        ingresoMongoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
