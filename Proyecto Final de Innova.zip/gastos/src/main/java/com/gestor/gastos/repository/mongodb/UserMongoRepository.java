package com.gestor.gastos.repository.mongodb;



import com.gestor.gastos.modelo.MongoDB.UserMongo;
import org.reactivestreams.Publisher;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMongoRepository extends MongoRepository<UserMongo, String> {
    Iterable<? extends Publisher<?>> findByUsername(String testuser);
}