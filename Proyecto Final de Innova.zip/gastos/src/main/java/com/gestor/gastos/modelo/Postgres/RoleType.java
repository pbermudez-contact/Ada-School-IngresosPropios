package com.gestor.gastos.modelo.Postgres;

public enum RoleType {
    ROLE_USER,
    ROLE_ADMIN
}
