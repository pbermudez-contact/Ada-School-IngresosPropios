package com.gestor.gastos.service.servicemongo;

import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.repository.mongodb.UserMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserMongoService {

    private final UserMongoRepository userMongoRepository;

    @Autowired
    public UserMongoService(UserMongoRepository userMongoRepository) {
        this.userMongoRepository = userMongoRepository;
    }

    public List<UserMongo> findAll() {
        return userMongoRepository.findAll();
    }

    public Optional<UserMongo> findById(String id) {
        return userMongoRepository.findById(id);
    }

    public UserMongo save(UserMongo userMongo) {
        return userMongoRepository.save(userMongo);
    }

    public void deleteById(String id) {
        userMongoRepository.deleteById(id);
    }

    public Optional<Object> update(String id, UserMongo user) {
        return null;
    }

    public void delete(String id) {
    }


}
