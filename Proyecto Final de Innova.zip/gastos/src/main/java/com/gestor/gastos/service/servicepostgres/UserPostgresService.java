package com.gestor.gastos.service.servicepostgres;

import com.gestor.gastos.modelo.Postgres.UserPostgres;
import com.gestor.gastos.repository.postgres.UserPostgresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserPostgresService {

    private final UserPostgresRepository userPostgresRepository;

    @Autowired
    public UserPostgresService(UserPostgresRepository userPostgresRepository) {
        this.userPostgresRepository = userPostgresRepository;
    }

    public List<UserPostgres> findAll() {
        return userPostgresRepository.findAll();
    }

    public Optional<UserPostgres> findById(Long id) {
        return userPostgresRepository.findById(id);
    }

    public UserPostgres save(UserPostgres userPostgres) {
        return userPostgresRepository.save(userPostgres);
    }

    public void deleteById(Long id) {
        userPostgresRepository.deleteById(id);
    }

    public void delete(Long id) {
    }

    public Optional<Object> update(Long id, UserPostgres user) {
        return null;
    }

    public UserPostgres findByUsername(String username) {
        return null;
    }


    public boolean arePasswordsMatching(Object password, Object password1) {
        // Asegúrate de que las contraseñas sean de tipo String antes de compararlas
        if (password instanceof String && password1 instanceof String) {
            return password.equals(password1);
        }
        // Si no son cadenas, podrías devolver false o lanzar una excepción
        return false;
    }

    public Object checkPassword(String testpass, String testpass1) {
        return 12345;
    }


}
