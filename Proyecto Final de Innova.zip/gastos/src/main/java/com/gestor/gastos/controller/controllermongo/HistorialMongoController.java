package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.HistorialMongo;
import com.gestor.gastos.service.servicemongo.HistorialMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mongo/historial")
public class HistorialMongoController {

    @Autowired
    private HistorialMongoService historialMongoService;

    @GetMapping
    public List<HistorialMongo> getAllHistorial() {
        return historialMongoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistorialMongo> getHistorialById(@PathVariable String id) {
        return historialMongoService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public HistorialMongo createHistorial(@RequestBody HistorialMongo historial) {
        return historialMongoService.save(historial);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateHistorial(@PathVariable String id, @RequestBody HistorialMongo historial) {
        return historialMongoService.update(id, historial)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHistorial(@PathVariable String id) {
        historialMongoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
