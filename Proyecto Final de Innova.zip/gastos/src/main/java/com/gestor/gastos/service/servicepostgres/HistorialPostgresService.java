package com.gestor.gastos.service.servicepostgres;

import com.gestor.gastos.modelo.Postgres.HistorialPostgres;
import com.gestor.gastos.repository.postgres.HistorialPostgresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HistorialPostgresService {

    private final HistorialPostgresRepository historialPostgresRepository;

    @Autowired
    public HistorialPostgresService(HistorialPostgresRepository historialPostgresRepository) {
        this.historialPostgresRepository = historialPostgresRepository;
    }

    public List<HistorialPostgres> findAll() {
        return historialPostgresRepository.findAll();
    }

    public Optional<HistorialPostgres> findById(Long id) {
        return historialPostgresRepository.findById(id);
    }

    public HistorialPostgres save(HistorialPostgres historialPostgres) {
        return historialPostgresRepository.save(historialPostgres);
    }

    public void deleteById(Long id) {
        historialPostgresRepository.deleteById(id);
    }


    public void delete(Long id) {
    }
}
