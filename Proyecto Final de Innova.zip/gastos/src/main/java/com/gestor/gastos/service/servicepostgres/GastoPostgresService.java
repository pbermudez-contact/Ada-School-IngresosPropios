package com.gestor.gastos.service.servicepostgres;

import com.gestor.gastos.modelo.Postgres.GastoPostgres;
import com.gestor.gastos.repository.postgres.GastoPostgresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GastoPostgresService {

    private final GastoPostgresRepository gastoPostgresRepository;

    @Autowired
    public GastoPostgresService(GastoPostgresRepository gastoPostgresRepository) {
        this.gastoPostgresRepository = gastoPostgresRepository;
    }

    public List<GastoPostgres> findAll() {
        return gastoPostgresRepository.findAll();
    }

    public Optional<GastoPostgres> findById(Long id) {
        return gastoPostgresRepository.findById(id);
    }

    public GastoPostgres save(GastoPostgres gastoPostgres) {
        return gastoPostgresRepository.save(gastoPostgres);
    }

    public void deleteById(Long id) {
        gastoPostgresRepository.deleteById(id);
    }

    public Optional<Object> update(Long id, GastoPostgres gasto) {
        return null;
    }

    public void delete(Long id) {
    }
}
