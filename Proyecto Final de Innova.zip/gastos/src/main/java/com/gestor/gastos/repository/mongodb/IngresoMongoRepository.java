package com.gestor.gastos.repository.mongodb;

import com.gestor.gastos.modelo.MongoDB.IngresoMongo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IngresoMongoRepository extends MongoRepository<IngresoMongo, String> {
}