package com.gestor.gastos.service.servicepostgres;

import com.gestor.gastos.modelo.Postgres.IngresoPostgres;
import com.gestor.gastos.repository.postgres.IngresoPostgresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IngresoPostgresService {

    private final IngresoPostgresRepository ingresoPostgresRepository;

    @Autowired
    public IngresoPostgresService(IngresoPostgresRepository ingresoPostgresRepository) {
        this.ingresoPostgresRepository = ingresoPostgresRepository;
    }

    public List<IngresoPostgres> findAll() {
        return ingresoPostgresRepository.findAll();
    }

    public Optional<IngresoPostgres> findById(Long id) {
        return ingresoPostgresRepository.findById(id);
    }

    public IngresoPostgres save(IngresoPostgres ingresoPostgres) {
        return ingresoPostgresRepository.save(ingresoPostgres);
    }

    public void deleteById(Long id) {
        ingresoPostgresRepository.deleteById(id);
    }

    public Optional<Object> update(Long id, IngresoPostgres ingreso) {
        return null;
    }

    public void delete(Long id) {
    }
}
