package com.gestor.gastos.controller.controllerpostgres;

import com.gestor.gastos.modelo.Postgres.HistorialPostgres;
import com.gestor.gastos.service.servicepostgres.HistorialPostgresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postgres/historial")
public class HistorialPostgresController {

    @Autowired
    private HistorialPostgresService historialPostgresService;

    @GetMapping
    public List<HistorialPostgres> getAllHistorial() {
        return historialPostgresService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistorialPostgres> getHistorialById(@PathVariable Long id) {
        return historialPostgresService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public HistorialPostgres createHistorial(@RequestBody HistorialPostgres historial) {
        return historialPostgresService.save(historial);
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHistorial(@PathVariable Long id) {
        historialPostgresService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
