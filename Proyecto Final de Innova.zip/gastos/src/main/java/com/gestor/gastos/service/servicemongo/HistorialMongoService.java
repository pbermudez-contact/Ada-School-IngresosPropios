package com.gestor.gastos.service.servicemongo;

import com.gestor.gastos.modelo.MongoDB.HistorialMongo;
import com.gestor.gastos.repository.mongodb.HistorialMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HistorialMongoService {

    private final HistorialMongoRepository historialMongoRepository;

    @Autowired
    public HistorialMongoService(HistorialMongoRepository historialMongoRepository) {
        this.historialMongoRepository = historialMongoRepository;
    }

    public List<HistorialMongo> findAll() {
        return historialMongoRepository.findAll();
    }

    public Optional<HistorialMongo> findById(String id) {
        return historialMongoRepository.findById(id);
    }

    public HistorialMongo save(HistorialMongo historialMongo) {
        return historialMongoRepository.save(historialMongo);
    }

    public void deleteById(String id) {
        historialMongoRepository.deleteById(id);
    }

    public Optional<Object> update(String id, HistorialMongo historial) {
        return null;
    }

    public void delete(String id) {
    }
}
