package com.gestor.gastos.controller.controllerpostgres;

import com.gestor.gastos.modelo.Postgres.UserPostgres;
import com.gestor.gastos.service.servicepostgres.UserPostgresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postgres/users")
public class UserPostgresController {

    @Autowired
    private UserPostgresService userPostgresService;

    @GetMapping
    public List<UserPostgres> getAllUsers() {
        return userPostgresService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserPostgres> getUserById(@PathVariable Long id) {
        return userPostgresService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public UserPostgres createUser(@RequestBody UserPostgres user) {
        return userPostgresService.save(user);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateUser(@PathVariable Long id, @RequestBody UserPostgres user) {
        return userPostgresService.update(id, user)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userPostgresService.delete(id);
        return ResponseEntity.noContent().build();
    }
}