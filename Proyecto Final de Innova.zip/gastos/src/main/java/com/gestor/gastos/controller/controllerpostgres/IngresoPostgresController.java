package com.gestor.gastos.controller.controllerpostgres;

import com.gestor.gastos.modelo.Postgres.IngresoPostgres;
import com.gestor.gastos.service.servicepostgres.IngresoPostgresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postgres/ingresos")
public class IngresoPostgresController {

    @Autowired
    private IngresoPostgresService ingresoPostgresService;

    @GetMapping
    public List<IngresoPostgres> getAllIngresos() {
        return ingresoPostgresService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<IngresoPostgres> getIngresoById(@PathVariable Long id) {
        return ingresoPostgresService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public IngresoPostgres createIngreso(@RequestBody IngresoPostgres ingreso) {
        return ingresoPostgresService.save(ingreso);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateIngreso(@PathVariable Long id, @RequestBody IngresoPostgres ingreso) {
        return ingresoPostgresService.update(id, ingreso)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteIngreso(@PathVariable Long id) {
        ingresoPostgresService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
