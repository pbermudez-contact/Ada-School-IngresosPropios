package com.gestor.gastos.modelo.Postgres;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

public interface UserPostgress {
    Collection<? extends GrantedAuthority> getAuthorities();
}
