package com.gestor.gastos.controller.controllerpostgres;

import com.gestor.gastos.modelo.Postgres.GastoPostgres;
import com.gestor.gastos.service.servicepostgres.GastoPostgresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postgres/gastos")
public class GastoPostgresController {

    @Autowired
    private GastoPostgresService gastoPostgresService;

    @GetMapping
    public List<GastoPostgres> getAllGastos() {
        return gastoPostgresService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<GastoPostgres> getGastoById(@PathVariable Long id) {
        return gastoPostgresService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public GastoPostgres createGasto(@RequestBody GastoPostgres gasto) {
        return gastoPostgresService.save(gasto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateGasto(@PathVariable Long id, @RequestBody GastoPostgres gasto) {
        return gastoPostgresService.update(id, gasto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGasto(@PathVariable Long id) {
        gastoPostgresService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
