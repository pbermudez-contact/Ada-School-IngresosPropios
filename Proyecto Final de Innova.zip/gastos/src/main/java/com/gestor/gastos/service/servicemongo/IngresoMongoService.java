package com.gestor.gastos.service.servicemongo;

import com.gestor.gastos.modelo.MongoDB.IngresoMongo;
import com.gestor.gastos.repository.mongodb.IngresoMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IngresoMongoService {

    private final IngresoMongoRepository ingresoMongoRepository;

    @Autowired
    public IngresoMongoService(IngresoMongoRepository ingresoMongoRepository) {
        this.ingresoMongoRepository = ingresoMongoRepository;
    }

    public List<IngresoMongo> findAll() {
        return ingresoMongoRepository.findAll();
    }

    public Optional<IngresoMongo> findById(String id) {
        return ingresoMongoRepository.findById(id);
    }

    public IngresoMongo save(IngresoMongo ingresoMongo) {
        return ingresoMongoRepository.save(ingresoMongo);
    }

    public void deleteById(String id) {
        ingresoMongoRepository.deleteById(id);
    }

    public Optional<Object> update(String id, IngresoMongo ingreso) {
        return null;
    }

    public void delete(String id) {
    }
}
