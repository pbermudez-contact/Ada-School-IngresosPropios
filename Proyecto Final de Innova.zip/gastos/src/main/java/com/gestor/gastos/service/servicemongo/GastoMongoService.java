package com.gestor.gastos.service.servicemongo;

import com.gestor.gastos.modelo.MongoDB.GastoMongo;
import com.gestor.gastos.repository.mongodb.GastoMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GastoMongoService {

    private final GastoMongoRepository gastoMongoRepository;

    @Autowired
    public GastoMongoService(GastoMongoRepository gastoMongoRepository) {
        this.gastoMongoRepository = gastoMongoRepository;
    }

    public List<GastoMongo> findAll() {
        return gastoMongoRepository.findAll();
    }

    public Optional<GastoMongo> findById(String id) {
        return gastoMongoRepository.findById(id);
    }

    public GastoMongo save(GastoMongo gastoMongo) {
        return gastoMongoRepository.save(gastoMongo);
    }

    public void deleteById(String id) {
        gastoMongoRepository.deleteById(id);
    }

    public Optional<Object> update(String id, GastoMongo gasto) {
        return null;
    }

    public void delete(String id) {
    }
}
