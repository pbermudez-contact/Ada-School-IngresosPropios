package com.gestor.gastos.modelo.MongoDB;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "users")
public class UserMongo {

    @Id
    private String id;

    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @NotBlank(message = "El apellido no puede estar vacío")
    private String apellido;

    @Email(message = "El correo no es válido")
    @NotBlank(message = "El correo no puede estar vacío")
    private String correo;

    @NotBlank(message = "La contraseña no puede estar vacía")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String contraseña;

    private String rol; // Puede ser un campo adicional para el rol del usuario

    public void setId(String number) {
    }

    public void setUsername(String testuser) {
    }

    public void setPassword(String testpass) {
    }

    public void setEmail(String mail) {
    }

    public String getUsername() {
        return null;
    }
}
