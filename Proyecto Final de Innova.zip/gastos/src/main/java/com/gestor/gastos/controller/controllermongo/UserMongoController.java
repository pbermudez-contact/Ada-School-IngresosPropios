package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.service.servicemongo.UserMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mongo/users")
public class UserMongoController {

    @Autowired
    private UserMongoService userMongoService;

    @GetMapping
    public List<UserMongo> getAllUsers() {
        return userMongoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserMongo> getUserById(@PathVariable String id) {
        return userMongoService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public UserMongo createUser(@RequestBody UserMongo user) {
        return userMongoService.save(user);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> updateUser(@PathVariable String id, @RequestBody UserMongo user) {
        return userMongoService.update(id, user)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable String id) {
        userMongoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
