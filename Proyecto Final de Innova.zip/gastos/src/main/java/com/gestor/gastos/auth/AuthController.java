/*package com.gestor.gastos.auth;

import com.gestor.gastos.config.JwtTokenProvider;
import com.gestor.gastos.modelo.Postgres.UserPostgres;
import com.gestor.gastos.service.servicepostgres.UserPostgresService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserPostgresService userPostgresService;

    @Autowired
    private JwtTokenProvider tokenProvider;

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody UserPostgres userPostgres) {
        UserPostgres user = userPostgresService.findByUsername(userPostgres.getUsername());

        // Reemplaza getClass con arePasswordsMatching
        if (user != null && userPostgresService.arePasswordsMatching(userPostgres.getPassword(), user.getPassword())) {
            String token = tokenProvider.generateToken(user.getUsername());
            Map<String, String> response = new HashMap<>();
            response.put("token", token);
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.badRequest().body("Invalid username or password");
        }
    }

}
*/