package com.gestor.gastos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GastosEInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
