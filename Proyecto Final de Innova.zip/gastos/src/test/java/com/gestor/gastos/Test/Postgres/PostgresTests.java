package com.gestor.gastos.Test.Postgres;

import com.gestor.gastos.controller.controllerpostgres.UserPostgresController;
import com.gestor.gastos.modelo.Postgres.UserPostgres;
import com.gestor.gastos.service.servicepostgres.UserPostgresService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class UserPostgresControllerTest {

    @InjectMocks
    private UserPostgresController userPostgresController;

    @Mock
    private UserPostgresService userPostgresService;

    private UserPostgres userPostgres;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        userPostgres = new UserPostgres();
        userPostgres.setId(1L);
        userPostgres.setUsername("testuser");
        userPostgres.setPassword("testpass");
        userPostgres.setEmail("test@example.com");
    }

    @Test
    void testGetUserById_Success() {
        when(userPostgresService.findById(1L)).thenReturn(Optional.of(userPostgres));

        ResponseEntity<UserPostgres> response = userPostgresController.getUserById(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(userPostgres, response.getBody());
    }

    @Test
    void testGetUserById_NotFound() {
        when(userPostgresService.findById(1L)).thenReturn(Optional.empty());

        ResponseEntity<UserPostgres> response = userPostgresController.getUserById(1L);

        assertEquals(404, response.getStatusCodeValue());
    }

}