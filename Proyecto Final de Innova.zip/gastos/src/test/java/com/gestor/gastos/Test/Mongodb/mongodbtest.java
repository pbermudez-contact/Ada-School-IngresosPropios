package com.gestor.gastos.Test.Mongodb;
import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.repository.mongodb.UserMongoRepository;
import com.gestor.gastos.service.servicemongo.UserMongoService;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class mongodbtest {
    @InjectMocks
    private UserMongoService userMongoService;

    @Mock
    private UserMongoRepository userMongoRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        UserMongo userMongo = new UserMongo();
        userMongo.setId("1");
        userMongo.setUsername("testuser");
        userMongo.setPassword("testpass");
        userMongo.setEmail("test@example.com");
    }

}
