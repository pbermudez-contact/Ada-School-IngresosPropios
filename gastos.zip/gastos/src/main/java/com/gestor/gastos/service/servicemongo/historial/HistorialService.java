package com.gestor.gastos.service.servicemongo.historial;

public class HistorialService {
}
