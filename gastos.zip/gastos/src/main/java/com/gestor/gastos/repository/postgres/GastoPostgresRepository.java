package com.gestor.gastos.repository.postgres;

import com.gestor.gastos.modelo.Postgres.GastoPostgres;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GastoPostgresRepository extends JpaRepository<GastoPostgres, Long> {
}