package com.gestor.gastos.controller.controllerpostgres;


public class HistorialPostgresController {

}
