package com.gestor.gastos.modelo.MongoDB;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Data//@Data Maneja la Lombok el cual maneja los getters y setter
//Document hace referencia a una tabla en mongoDb
@Document(collection = "usuario")
public class UserMongo {

    @Id
    private String id;

    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @NotBlank(message = "El apellido no puede estar vacío")
    private String apellido;

    @Email(message = "El correo no es válido")
    @NotBlank(message = "El correo no puede estar vacío")
    private String email;

    @NotBlank(message = "La contraseña no puede estar vacía")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String password;

    public UserMongo(String contraseña) {
        this.password = new BCryptPasswordEncoder().encode(password);
    }

    public String getPassword() {
        return password;
    }

    //aplicar sifrado al realizar la la operacion del update
    public void setPassword(String password) {
        //cifrar la contraseña no importando se cambie siempre
        this.password = new BCryptPasswordEncoder().encode(password);
    }

}
