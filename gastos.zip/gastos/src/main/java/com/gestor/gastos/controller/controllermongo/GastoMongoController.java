package com.gestor.gastos.controller.controllermongo;


import com.gestor.gastos.modelo.MongoDB.GastoMongo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gasto")
public class GastoMongoController {

    private final com.gestor.gastos.service.servicemongo.gasto.GastoMongoService gastoMongoService;

    @Autowired
    public GastoMongoController(com.gestor.gastos.service.servicemongo.gasto.GastoMongoService gastoMongoService) {
        this.gastoMongoService = gastoMongoService;
    }

    // Crear un nuevo gasto
    @PostMapping
    public ResponseEntity<GastoMongo> crearGasto(@RequestBody GastoMongo gasto) {
        GastoMongo nuevoGasto = gastoMongoService.crearGasto(gasto);
        return ResponseEntity.ok(nuevoGasto);
    }

    // Obtener todos los gastos
    @GetMapping
    public ResponseEntity<List<GastoMongo>> obtenerTodosLosGastos() {
        List<GastoMongo> gastos = gastoMongoService.obtenerTodosLosGastos();
        return ResponseEntity.ok(gastos);
    }

    // Obtener un gasto por ID
    @GetMapping("/{id}")
    public ResponseEntity<GastoMongo> obtenerGastoPorId(@PathVariable String id) {
        GastoMongo gasto = gastoMongoService.obtenerGastoPorId(id);
        if (gasto != null) {
            return ResponseEntity.ok(gasto);
        }
        return ResponseEntity.notFound().build();
    }

    // Actualizar un gasto
    @PutMapping("/{id}")
    public ResponseEntity<GastoMongo> actualizarGasto(@PathVariable String id, @RequestBody GastoMongo gasto) {
        GastoMongo gastoActualizado = gastoMongoService.actualizarGasto(id, gasto);
        if (gastoActualizado != null) {
            return ResponseEntity.ok(gastoActualizado);
        }
        return ResponseEntity.notFound().build();
    }

    // Eliminar un gasto
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarGasto(@PathVariable String id) {
        boolean eliminado = gastoMongoService.eliminarGasto(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
