package com.gestor.gastos.repository;

import com.gestor.gastos.modelo.MongoDB.UserMongo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends MongoRepository<UserMongo, String> {
    Optional<UserMongo> findByEmail(String email);
    Optional<UserMongo> findById(String id);
}