package com.gestor.gastos.service.servicemongo.user;

import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceIm implements UserService{
        @Autowired
        private UsuarioRepository usuarioRepository;

        @Override
        public List<UserMongo> findAll(){
            return usuarioRepository.findAll();
        }

        @Override
        public UserMongo findById(String id) {
            return usuarioRepository.findById(id).orElse(null);
        }

        @Override
        public UserMongo save(UserMongo userMongo) {
            return usuarioRepository.save(userMongo);
        }

        @Override
        public UserMongo update(String id, UserMongo userMongo){
            UserMongo existeUs = usuarioRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Usuario no coincide con ninguno creado"));
            if (userMongo.getEmail() != null){
                existeUs.setNombre(userMongo.getEmail());
            }
            return usuarioRepository.save(existeUs);
        }

        @Override
        public void deleteById(String id){
            usuarioRepository.deleteById(id);
        }


}
