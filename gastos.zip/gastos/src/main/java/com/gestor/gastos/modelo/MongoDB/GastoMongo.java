package com.gestor.gastos.modelo.MongoDB;

import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Document(collection = "gastos")
public class GastoMongo {

    @Id
    private String id;

    @NotBlank(message = "La descripción no puede estar vacía")
    private String descripcion;

    @NotNull(message = "El monto no puede ser nulo")
    private BigDecimal monto;

    @NotNull(message = "La fecha no puede ser nula")
    private LocalDate fecha;

    private String usuarioId; // Referencia al ID del usuario (UserMongo)
}