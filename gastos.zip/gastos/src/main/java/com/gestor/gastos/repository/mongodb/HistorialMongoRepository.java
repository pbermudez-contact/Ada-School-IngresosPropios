package com.gestor.gastos.repository.mongodb;

import com.gestor.gastos.modelo.MongoDB.HistorialMongo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HistorialMongoRepository extends MongoRepository<HistorialMongo, String> {
}