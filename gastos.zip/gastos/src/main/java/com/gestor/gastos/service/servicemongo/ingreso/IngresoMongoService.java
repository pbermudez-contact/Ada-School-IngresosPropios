package com.gestor.gastos.service.servicemongo.ingreso;

import com.gestor.gastos.modelo.MongoDB.IngresoMongo;

import java.util.List;

public interface IngresoMongoService {
    // Crear un nuevo ingreso
    IngresoMongo crearIngreso(IngresoMongo ingreso);
    // Obtener todos los ingresos
    List<IngresoMongo> obtenerTodosLosIngresos();
    // Obtener un ingreso por ID
    IngresoMongo obtenerIngresoPorId(String id);
    // Actualizar un ingreso
    IngresoMongo actualizarIngreso(String id, IngresoMongo ingreso);
    // Eliminar un ingreso
    boolean eliminarIngreso(String id);
}
