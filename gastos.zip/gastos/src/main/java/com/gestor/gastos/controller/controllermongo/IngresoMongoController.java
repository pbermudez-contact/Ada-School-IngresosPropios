package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.IngresoMongo;
import com.gestor.gastos.service.servicemongo.ingreso.IngresoMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ingreso")
public class IngresoMongoController {

    private final IngresoMongoService ingresoMongoService;

    @Autowired
    public IngresoMongoController(IngresoMongoService ingresoMongoService) {
        this.ingresoMongoService = ingresoMongoService;
    }

    // Crear un nuevo ingreso
    @PostMapping
    public ResponseEntity<IngresoMongo> crearIngreso(@RequestBody IngresoMongo ingreso) {
        IngresoMongo nuevoIngreso = ingresoMongoService.crearIngreso(ingreso);
        return ResponseEntity.ok(nuevoIngreso);
    }

    // Obtener todos los ingresos
    @GetMapping
    public ResponseEntity<List<IngresoMongo>> obtenerTodosLosIngresos() {
        List<IngresoMongo> ingresos = ingresoMongoService.obtenerTodosLosIngresos();
        return ResponseEntity.ok(ingresos);
    }

    // Obtener un ingreso por ID
    @GetMapping("/{id}")
    public ResponseEntity<IngresoMongo> obtenerIngresoPorId(@PathVariable String id) {
        IngresoMongo ingreso = ingresoMongoService.obtenerIngresoPorId(id);
        if (ingreso != null) {
            return ResponseEntity.ok(ingreso);
        }
        return ResponseEntity.notFound().build();
    }

    // Actualizar un ingreso
    @PutMapping("/{id}")
    public ResponseEntity<IngresoMongo> actualizarIngreso(@PathVariable String id, @RequestBody IngresoMongo ingreso) {
        IngresoMongo ingresoActualizado = ingresoMongoService.actualizarIngreso(id, ingreso);
        if (ingresoActualizado != null) {
            return ResponseEntity.ok(ingresoActualizado);
        }
        return ResponseEntity.notFound().build();
    }

    // Eliminar un ingreso
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarIngreso(@PathVariable String id) {
        boolean eliminado = ingresoMongoService.eliminarIngreso(id);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
