package com.gestor.gastos.service.Auth;

import com.gestor.gastos.config.JwtTokenUtil;
import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public String login(String email, String password){
        if (email == null || password == null){
            throw new RuntimeException("Invalid credentials");
        }

        Optional<UserMongo> usuario = usuarioRepository.findByEmail(email);

        if(usuario.isPresent() && passwordEncoder.matches(password, usuario.get().getPassword())){
            System.out.println(usuario);
            return  jwtTokenUtil.generateToken(usuario.get().getId());
        } else {
            throw new RuntimeException("Credenciales Invalidas");
        }
    }

}