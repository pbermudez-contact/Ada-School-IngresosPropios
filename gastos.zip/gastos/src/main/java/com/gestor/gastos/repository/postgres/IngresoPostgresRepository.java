package com.gestor.gastos.repository.postgres;

import com.gestor.gastos.modelo.Postgres.IngresoPostgres;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IngresoPostgresRepository extends JpaRepository<IngresoPostgres, Long> {
}