package com.gestor.gastos.service.servicemongo.user;

import com.gestor.gastos.modelo.MongoDB.UserMongo;

import java.util.List;

public interface UserService {
    List<UserMongo> findAll();
    UserMongo findById(String id);
    UserMongo save(UserMongo userMongo);
    UserMongo update (String id, UserMongo userMongo);
    void deleteById(String id);
}
