package com.gestor.gastos.controller.controllermongo;

public class HistorialMongoController {


}
