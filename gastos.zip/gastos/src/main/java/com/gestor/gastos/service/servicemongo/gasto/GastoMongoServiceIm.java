package com.gestor.gastos.service.servicemongo.gasto;

import com.gestor.gastos.modelo.MongoDB.GastoMongo;

import com.gestor.gastos.repository.mongodb.GastoMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GastoMongoServiceIm implements GastoMongoService {

    private final GastoMongoRepository gastoMongoRepository;

    @Autowired
    public GastoMongoServiceIm(GastoMongoRepository gastoMongoRepository) {
        this.gastoMongoRepository = gastoMongoRepository;
    }

    // Crear un nuevo gasto
    @Override
    public GastoMongo crearGasto(GastoMongo gasto) {
        return gastoMongoRepository.save(gasto);
    }

    // Obtener todos los gastos
    @Override
    public List<GastoMongo> obtenerTodosLosGastos() {
        return gastoMongoRepository.findAll();
    }

    // Obtener un gasto por ID
    @Override
    public GastoMongo obtenerGastoPorId(String id) {
        Optional<GastoMongo> gasto = gastoMongoRepository.findById(id);
        return gasto.orElse(null);
    }

    // Actualizar un gasto
    @Override
    public GastoMongo actualizarGasto(String id, GastoMongo gasto) {
        if (gastoMongoRepository.existsById(id)) {
            gasto.setId(id);
            return gastoMongoRepository.save(gasto);
        }
        return null;
    }

    // Eliminar un gasto
    @Override
    public boolean eliminarGasto(String id) {
        if (gastoMongoRepository.existsById(id)) {
            gastoMongoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
