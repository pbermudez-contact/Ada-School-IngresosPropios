package com.gestor.gastos.service.servicemongo.ingreso;


import com.gestor.gastos.modelo.MongoDB.IngresoMongo;
import com.gestor.gastos.repository.mongodb.IngresoMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IngresoServiceIm implements IngresoMongoService {

    private final IngresoMongoRepository ingresoMongoRepository;

    @Autowired
    public IngresoServiceIm(IngresoMongoRepository ingresoMongoRepository) {
        this.ingresoMongoRepository = ingresoMongoRepository;
    }

    // Crear un nuevo ingreso
    @Override
    public IngresoMongo crearIngreso(IngresoMongo ingreso) {
        return ingresoMongoRepository.save(ingreso);
    }

    // Obtener todos los ingresos
    @Override
    public List<IngresoMongo> obtenerTodosLosIngresos() {
        return ingresoMongoRepository.findAll();
    }

    // Obtener un ingreso por ID
    @Override
    public IngresoMongo obtenerIngresoPorId(String id) {
        Optional<IngresoMongo> ingreso = ingresoMongoRepository.findById(id);
        return ingreso.orElse(null);
    }

    // Actualizar un ingreso
    @Override
    public IngresoMongo actualizarIngreso(String id, IngresoMongo ingreso) {
        if (ingresoMongoRepository.existsById(id)) {
            ingreso.setId(id);
            return ingresoMongoRepository.save(ingreso);
        }
        return null;
    }

    // Eliminar un ingreso
    @Override
    public boolean eliminarIngreso(String id) {
        if (ingresoMongoRepository.existsById(id)) {
            ingresoMongoRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
