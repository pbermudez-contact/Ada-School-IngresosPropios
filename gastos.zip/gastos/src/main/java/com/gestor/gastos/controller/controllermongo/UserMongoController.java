package com.gestor.gastos.controller.controllermongo;

import com.gestor.gastos.modelo.MongoDB.UserMongo;
import com.gestor.gastos.service.servicemongo.user.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserMongoController {
    @Autowired
    private UserService userService;

    @GetMapping
    public List<UserMongo> findAll() {
        return userService.findAll();
    }

    @GetMapping("/{idUsuario}")
    public UserMongo findById(@PathVariable String idUsuario) {
        return userService.findById(idUsuario);
    }

    @PostMapping
    public UserMongo save(@RequestBody UserMongo usuario) {
        return userService.save(usuario);
    }

    @PutMapping("/{idUsuario}")
    public UserMongo update(@PathVariable String idUsuario,@RequestBody UserMongo usuario){
        return userService.update(idUsuario, usuario);
    }

    @DeleteMapping("/{idUsuario}")
    public void deletedById(@PathVariable String idUsuario){
        userService.deleteById(idUsuario);
    }
}
