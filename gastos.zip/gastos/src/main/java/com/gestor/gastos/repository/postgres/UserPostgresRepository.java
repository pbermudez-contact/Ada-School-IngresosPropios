package com.gestor.gastos.repository.postgres;

import com.gestor.gastos.modelo.Postgres.UserPostgres;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserPostgresRepository extends JpaRepository<UserPostgres, Long> {

}