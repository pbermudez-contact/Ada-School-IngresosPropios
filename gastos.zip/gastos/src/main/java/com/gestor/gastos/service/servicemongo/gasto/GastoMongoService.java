package com.gestor.gastos.service.servicemongo.gasto;

import com.gestor.gastos.modelo.MongoDB.GastoMongo;

import java.util.List;

public interface GastoMongoService {
    // Crear un nuevo gasto
    GastoMongo crearGasto(GastoMongo gasto);
    // Obtener todos los gastos
    List<GastoMongo> obtenerTodosLosGastos();
    // Obtener un gasto por ID
    GastoMongo obtenerGastoPorId(String id);
    // Actualizar un gasto
    GastoMongo actualizarGasto(String id, GastoMongo gasto);
    // Eliminar un gasto
    boolean eliminarGasto(String id);
}
